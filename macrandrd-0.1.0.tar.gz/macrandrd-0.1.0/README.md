# macrandrd

### Just a tiny OpenBSD daemon to change periodically MAC addresses

*OpenBSD* MAC address randomization daemon

Giacomo Picchiarelli <gpicchiarelli@gmail.com>
